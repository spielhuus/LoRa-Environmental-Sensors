#ifndef PINS_H
#define PINS_H

/*** ATtiny85 ******/
#define NSS_RFM PB4       
#define NSS_BME280 PB3

#endif
